export { fromFetch } from '../internal/observable/dom/fetch';
