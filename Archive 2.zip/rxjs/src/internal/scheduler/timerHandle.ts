export type TimerHandle = number | ReturnType<typeof setTimeout>;
