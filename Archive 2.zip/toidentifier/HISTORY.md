1.0.1 / 2021-11-14
==================

  * pref: enable strict mode

1.0.0 / 2018-07-09
==================

  * Initial release
