function _classNameTDZError(e) {
  throw new ReferenceError('Class "' + e + '" cannot be referenced in computed property keys.');
}
module.exports = _classNameTDZError, module.exports.__esModule = true, module.exports["default"] = module.exports;