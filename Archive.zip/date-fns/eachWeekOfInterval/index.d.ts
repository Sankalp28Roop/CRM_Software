// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { eachWeekOfInterval } from 'date-fns'
export default eachWeekOfInterval
