// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { lightFormat } from 'date-fns'
export default lightFormat
