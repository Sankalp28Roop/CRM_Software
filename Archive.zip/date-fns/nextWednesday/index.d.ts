// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { nextWednesday } from 'date-fns'
export default nextWednesday
